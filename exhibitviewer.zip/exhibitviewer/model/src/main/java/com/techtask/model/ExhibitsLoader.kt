package com.techtask.model

interface ExhibitsLoader {
    fun getExhibitList(): List<Exhibit>
}