package com.techtask.exhibitviewer.ui

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProvider
import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.techtask.exhibitviewer.R
import dagger.android.AndroidInjection
import com.techtask.exhibitviewer.data.ActivityViewModel
import kotlinx.android.synthetic.main.activity_main.*
import javax.inject.Inject

class MainActivity : AppCompatActivity() {
    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory
    private lateinit var viewModel: ActivityViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initRecyclerAdapter()
        observeViewModel()
    }

    private fun initRecyclerAdapter() {
        itemsList.adapter = ExhAdapter()
    }

    private fun observeViewModel() {
        viewModel = ViewModelProviders.of(this, viewModelFactory).get(ActivityViewModel::class.java)
        viewModel.getExhibitList().observe(this, Observer {
            if (!it.isNullOrEmpty()) (itemsList.adapter as ExhAdapter).addNewItems(it)
        })
    }
}

